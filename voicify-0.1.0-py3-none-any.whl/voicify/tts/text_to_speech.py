import openai
import httpx
class TextToSpeech:
    def __init__(self):
        self.base_url = "https://kokoro-fastapi-models.apps.llama-rag-pool-b84hp.aws.rh-ods.com/v1"
        self.output_file = "output.wav"

    def write_voice(self, text: str):

        try:
            # 1. Create a custom httpx client with SSL verification disabled
            unverified_client = httpx.Client(verify=False)

            # Create an OpenAI client and attach the session
            client = openai.OpenAI(
                base_url=self.base_url,
                api_key="not-needed",
                http_client=unverified_client,
            )

            with client.audio.speech.with_streaming_response.create(
                model="kokoro",
                voice="af_sky+af_bella", #single or multiple voicepack combo
                input=text
            ) as response:
                response.stream_to_file(self.output_file)
        except Exception as e:
            print(e)
                