#!/usr/bin/env python3
import whisper

class SpeechToText:
    def __init__(self):
        self.model = whisper.load_model("base")

    def speech_to_text(self, wav_path: str):
        text = self.model.transcribe(wav_path)
        return text["text"].strip()
